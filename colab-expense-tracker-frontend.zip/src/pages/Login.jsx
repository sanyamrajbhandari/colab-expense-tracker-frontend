import React from "react";
import "../css/Login.css";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const navigate = useNavigate();

  return (
    <div className="container">
      <div className="card">
        <div className="logo">
          <div className="logo-top">
            <div className="logo-icon">💳</div>
            <h1>
              Spend<span>Wise</span>
            </h1>
          </div>

          <p>Enter your credentials to access your insights.</p>
        </div>

        <div className="form">
          <label>Email Address</label>
          <div className="input-group">
            <span className="icon">📧</span>
            <input type="email" placeholder="name@company.com" />
          </div>

          <div className="password-header">
            <label>Password</label>
            <span className="forgot">Forgot Password?</span>
          </div>

          <div className="input-group">
            <span className="icon">🔒</span>
            <input type="password" placeholder="••••••••" />
            <span className="eye">👁️</span>
          </div>

          <div className="remember">
            <input type="checkbox" />
            <span>Remember me for 30 days</span>
          </div>

          <button onClick={() => navigate("/dashboard")}>Log In →</button>
        </div>

        <p className="signup">
          New to SpendWise?{" "}
          <span onClick={() => navigate("/signup")}>Create an Account</span>
        </p>
      </div>
    </div>
  );
};

export default Login;
